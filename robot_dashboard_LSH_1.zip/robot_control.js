// robot_control.js
// 위에서 만든 addLog 함수를 끌어다 씁니다.
document.getElementById('btn-charge').addEventListener('click', () => addLog('정상', '충전소 이동 명령 하달'));
document.getElementById('btn-tts').addEventListener('click', () => addLog('정상', 'TTS 안내 방송 테스트'));
document.getElementById('btn-open').addEventListener('click', () => addLog('정상', '적재함 개방 완료'));
document.getElementById('btn-start-pos').addEventListener('click', () => addLog('정상', '시작 위치 재설정됨'));
document.getElementById('btn-pause').addEventListener('click', () => addLog('주의', '로봇 강제 일시정지'));
document.getElementById('btn-restart').addEventListener('click', () => addLog('정상', '서비스 재시작 중...'));
document.getElementById('btn-shutdown').addEventListener('click', () => addLog('주의', '시스템 종료 시퀀스 가동'));// 예시: 충전소 이동 버튼 클릭 시
document.getElementById('btn-charge').addEventListener('click', () => {
    
    // DB에 넣을 데이터 준비
    const logData = {
        type: '정상',
        message: '충전소 이동 명령 하달'
    };

    // 화면(UI) 로그 창에도 추가
    if(typeof addLog === 'function') {
        addLog(logData.type, logData.message);
    }

    // ★ Flask API(5000번 포트)로 데이터 전송!
    fetch('http://127.0.0.1:5000/api/insert_log', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(logData)
    })
    .then(response => response.json())
    .then(data => {
        console.log("Flask 서버 응답:", data.message);
    })
    .catch(error => {
        console.error("서버 통신 에러:", error);
    });
});
