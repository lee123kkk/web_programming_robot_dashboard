// log_handler.js

// 1. 로그 추가 및 DB 전송 함수
function addLog(type, message) {
    // ---- [A. 기존 화면(UI)에 글자 띄우기] ----
    const tbody = document.querySelector('.log-table tbody');
    if (!tbody) return;

    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0]; 
    let statusClass = type === '정상' ? 'status-ok' : 'status-warn';

    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>${timeStr}</td>
        <td class="${statusClass}">${type}</td>
        <td>${message}</td>
    `;
    
    tbody.prepend(tr);
    if(tbody.children.length > 10) {
        tbody.lastChild.remove();
    }

    // ---- [B. ★ 추가됨: Flask 백엔드(DB)로 데이터 몰래 쏴주기] ----
    fetch('http://127.0.0.1:5000/api/insert_log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // UI에 찍힌 type과 message를 그대로 포장해서 보냅니다.
        body: JSON.stringify({ type: type, message: message }) 
    })
    .then(response => response.json())
    .then(data => {
        console.log("DB 백업 완료:", data.message); // F12 개발자 도구에서만 몰래 확인
    })
    .catch(error => {
        console.error("DB 통신 실패:", error);
    });
}

// 2. 로그 전체 삭제 함수 (층 변경 시 호출됨)
function clearLog() {
    const tbody = document.querySelector('.log-table tbody');
    if (tbody) {
        tbody.innerHTML = ''; 
    }
}
