from flask import Flask, request, jsonify
from flask_cors import CORS
import pymysql
from datetime import datetime

app = Flask(__name__)
# 프론트엔드(8081 포트)에서 백엔드(5000 포트)로 요청을 보낼 수 있도록 CORS 허용
CORS(app) 

# ★ MariaDB 접속 정보 (나중에 실제 계정 정보로 변경하세요!)
DB_CONFIG = {
    'host': '127.0.0.1',
    'user': 'your_db_user',       # 예: 'root'
    'password': 'your_password',  # 예: '1234'
    'database': 'your_db_name',   # 예: 'fms_db'
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

# 로그 저장 API 엔드포인트
@app.route('/api/insert_log', methods=['POST'])
def insert_log():
    data = request.json
    log_type = data.get('type')       # 예: '정상'
    log_message = data.get('message') # 예: '충전소 이동 명령 하달'

    try:
        # 1. DB 연결
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            # 2. 쿼리문 작성 (테이블 이름과 컬럼명은 나중에 맞춰서 수정)
            sql = "INSERT INTO robot_logs (log_time, log_type, log_message) VALUES (%s, %s, %s)"
            cursor.execute(sql, (datetime.now(), log_type, log_message))
        
        # 3. DB에 확정 저장(Commit)
        connection.commit()
        return jsonify({"status": "success", "message": "로그가 DB에 저장되었습니다."}), 200

    except Exception as e:
        print(f"DB 저장 오류: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

    finally:
        # 4. 연결 종료
        if 'connection' in locals() and connection.open:
            connection.close()

if __name__ == '__main__':
    # 5000번 포트에서 서버 실행
    app.run(host='0.0.0.0', port=5000, debug=True)
