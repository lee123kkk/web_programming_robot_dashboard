// joystick.js

const dirBtns = document.querySelectorAll('.dir-btn');

dirBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        const direction = e.target.innerText;
        let actionMsg = "";

        // 누른 버튼에 따라 메시지 생성
        if (direction === '▲') actionMsg = "전진 (↑)";
        else if (direction === '▼') actionMsg = "후진 (↓)";
        else if (direction === '◀') actionMsg = "좌회전 (←)";
        else if (direction === '▶') actionMsg = "우회전 (→)";
        else if (direction === '■') actionMsg = "긴급 정지";

        // ★ 여기서 addLog만 부르면 화면에도 뜨고 알아서 DB로도 날아갑니다!
        if (actionMsg !== "") {
            addLog('정상', `수동 제어: ${actionMsg}`);
        }
    });
});
