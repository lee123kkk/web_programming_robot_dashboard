// static/js/elevator_sim.js

// 엘리베이터 시뮬레이션 글로벌 객체 정의
window.ElevatorSim = {
    // 층수 정보를 높이 퍼센트로 변환하는 맵 (최하층 B3F ~ 최상층 10F)
    floorMap: {
        'B3F': 0, 'B2F': 8, 'B1F': 16,
        '1F': 24, '2F': 32, '3F': 40, '4F': 48, '5F': 56,
        '6F': 64, '7F': 72, '8F': 80, '9F': 88, '10F': 100
    },

    // 현재 로봇의 층수에 맞춰 화면의 빨간 바를 업데이트하는 함수
    updateFloorDisplay: function(currentFloor) {
        const barElement = document.getElementById('elevator-bar');
        
        if (!barElement) return; // 엘리베이터 요소를 찾을 수 없으면 무시

        const percentHeight = this.floorMap[currentFloor];

        if (percentHeight !== undefined) {
            // CSS의 height 속성을 변경하여 빨간 바를 위아래로 움직임 (트랜지션 효과 적용됨)
            barElement.style.height = `${percentHeight}%`;
            
            // 정보 텍스트의 색상을 강조하는 등의 추가 효과 가능
            const infoFloor = document.getElementById('info-floor');
            if (infoFloor) infoFloor.classList.add('floor-highlight');
            setTimeout(() => { if(infoFloor) infoFloor.classList.remove('floor-highlight'); }, 300);
            
            console.log(`엘리베이터 동적 업데이트: ${currentFloor} -> ${percentHeight}%`);
        } else {
            // 유효하지 않은 층수일 경우 1층에 고정
            barElement.style.height = `24%`;
        }
    }
};

// 최초 1회 초기화 (기본 1층 위치)
window.addEventListener('load', () => {
    if(typeof ElevatorSim !== 'undefined') {
        ElevatorSim.updateFloorDisplay('1F'); 
    }
});
