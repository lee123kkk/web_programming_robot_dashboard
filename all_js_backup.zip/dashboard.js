// static/js/dashboard.js

// 1. 로봇 상태 및 시스템 정보 실시간 업데이트 (1초 주기로 백엔드 API 호출)
async function updateDashboardData() {
    try {
        const response = await fetch('/api/v1/robot/status');
        const data = await response.json();

        // [시스템 상태 카드 정보 업데이트]
        document.querySelector('.stat-item strong').textContent = `${data.battery_percent} %`; // 배터리
        document.querySelector('.status-item strong').textContent = `${data.cpu_usage} %`;     // CPU 사용량
        document.querySelector('.memory-item strong').textContent = `${data.memory_usage} %`; // 메모리 사용량

        // [로봇 정보 카드 업데이트]
        const elevatorBar = document.getElementById('elevator-bar');
        if (elevatorBar) {
            // 현재 층 정보를 엘리베이터 시뮬레이션 엔진에 전달
            ElevatorSim.updateFloorDisplay(data.location.floor); // (아래에서 정의함)
        }
        
        // 정보 텍스트 업데이트
        document.getElementById('info-floor').textContent = data.location.floor;
        document.getElementById('info-speed').textContent = data.speed.toFixed(2);

    } catch (error) {
        console.error("데이터 업데이트 실패:", error);
    }
}

// 2. ★ MariaDB 실제 로그 실시간 업데이트
async function updateRealDBLogs() {
    try {
        const response = await fetch('/api/v1/logs'); // /logs API 호출 (실제 DB 조회)
        const logs = await response.json();
        
        const tbody = document.querySelector('.log-table tbody');
        tbody.innerHTML = ''; // 기존 표 내용 비우기

        logs.forEach(log => {
            const timeStr = log.time.split(' ')[1]; // 시간만 표시 (예: 14:30:05)
            
            // 구분(type)에 따른 배지 색상 변경
            const typeBadge = log.type === '정상' ? '<span class="badge bg-green">정상</span>' : 
                               log.type === '경고' ? '<span class="badge bg-yellow">경고</span>' :
                               '<span class="badge bg-blue">명령</span>';

            const row = `<tr>
                <td>${timeStr}</td>
                <td>${typeBadge}</td>
                <td class="text-left">${log.message}</td>
            </tr>`;
            tbody.innerHTML += row;
        });
        
        console.log("실제 DB 로그 업데이트 완료");

    } catch (error) {
        console.error("로그 업데이트 실패:", error);
    }
}

// 1초(1000ms)마다 두 함수 실행
setInterval(updateDashboardData, 1000);
setInterval(updateRealDBLogs, 1000);

// 페이지 로드 시 즉시 1회 실행
window.addEventListener('load', () => {
    updateDashboardData();
    updateRealDBLogs();
});
