// robot_control.js

// 1. 충전소 이동 버튼
document.getElementById('btn-charge').addEventListener('click', () => {
    MapEngine.sendToCharger(); // 우하단으로 이동
    addLog('정상', '충전소 복귀 명령 수행 중');
});

// 2. 위치 설정 버튼 (현재 위치를 Home으로)
document.getElementById('btn-start-pos').addEventListener('click', () => {
    MapEngine.setHomePosition(); // 현재 좌표 기억
    addLog('정상', `현재 위치를 [${MapEngine.currentFloor}] 층의 기본 위치로 설정`);
});

// 3. 일시정지 버튼 (로그만 기록)
document.getElementById('btn-pause').addEventListener('click', () => {
    addLog('정상', '로봇 제어 일시정지');
});

// 4. 층수 네비게이션 연결 (층을 누르면 맵이 바뀌도록)
const floorItems = document.querySelectorAll('.floor-nav li');
floorItems.forEach(item => {
    item.addEventListener('click', (e) => {
        // 기존 active 클래스 제거하고 클릭한 곳에 추가
        floorItems.forEach(li => li.classList.remove('active'));
        e.target.classList.add('active');

        const selectedFloor = e.target.innerText;
        
        // 맵 엔진의 층수를 변경! (해당 층의 로봇과 장애물 상태를 불러옴)
        MapEngine.changeFloor(selectedFloor);
        
        // 화면 표 비우기 및 로그 추가
        if(typeof clearLog === 'function') clearLog();
        addLog('정상', `[${selectedFloor}] 층 시스템 초기화 완료`);
    });
});
