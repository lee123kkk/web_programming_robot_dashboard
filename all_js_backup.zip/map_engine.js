// map_engine.js (로봇 위치 고정 버전 - 벽 갇힘 발생 버전)

const canvas = document.getElementById('floorMap');
const ctx = canvas.getContext('2d');

const LOGICAL_WIDTH = 800;
const LOGICAL_HEIGHT = 300;

const floorStates = {};
const floors = ['10F','9F','8F','7F','6F','5F','4F','3F','2F','1F','B1F','B2F','B3F'];

const defaultObstacles = [
    { x: 150, y: 100, w: 100, h: 100 },
    { x: 400, y: 100, w: 150, h: 100 }
];

floors.forEach(f => {
    floorStates[f] = {
        robot: { 
            x: 500, y: 150,    // 모든 층에서 동일한 위치로 고정
            homeX: 500, homeY: 150,
            size: 20 
        },
        obstacles: defaultObstacles
    };
});

window.MapEngine = {
    currentFloor: '4F',

    changeFloor: function(floor) {
        if(floorStates[floor]) {
            this.currentFloor = floor;
            document.getElementById('map-title').innerText = `Map View - ${floor}`;
            this.draw();
        }
    },

    moveRobot: function(dx, dy) {
        const state = floorStates[this.currentFloor];
        const r = state.robot;
        let newX = r.x + dx;
        let newY = r.y + dy;

        if (newX < 30 || newX > LOGICAL_WIDTH - 30) newX = r.x;
        if (newY < 30 || newY > LOGICAL_HEIGHT - 30) newY = r.y;

        let hitObstacle = false;
        state.obstacles.forEach(obs => {
            if (newX + r.size/2 > obs.x && newX - r.size/2 < obs.x + obs.w &&
                newY + r.size/2 > obs.y && newY - r.size/2 < obs.y + obs.h) {
                hitObstacle = true;
            }
        });

        if (!hitObstacle) {
            r.x = newX;
            r.y = newY;
            this.draw();
            return true;
        }
        return false;
    },

    sendToCharger: function() {
        const r = floorStates[this.currentFloor].robot;
        r.x = LOGICAL_WIDTH - 50; 
        r.y = LOGICAL_HEIGHT - 50;
        this.draw();
    },

    setHomePosition: function() {
        const r = floorStates[this.currentFloor].robot;
        r.homeX = r.x;
        r.homeY = r.y;
    },

    draw: function() {
        const container = document.getElementById('map-container');
        if (!container || container.clientWidth === 0) return;
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const scaleX = canvas.width / LOGICAL_WIDTH;
        const scaleY = canvas.height / LOGICAL_HEIGHT;
        const state = floorStates[this.currentFloor];

        ctx.strokeStyle = '#34495e';
        ctx.lineWidth = 4;
        ctx.strokeRect(20 * scaleX, 20 * scaleY, (LOGICAL_WIDTH - 40) * scaleX, (LOGICAL_HEIGHT - 40) * scaleY);

        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        for(let i=0; i<LOGICAL_WIDTH; i+=20) {
            ctx.beginPath(); ctx.moveTo(i*scaleX, 20*scaleY); ctx.lineTo(i*scaleX, (LOGICAL_HEIGHT-20)*scaleY); ctx.stroke();
        }
        for(let i=0; i<LOGICAL_HEIGHT; i+=20) {
            ctx.beginPath(); ctx.moveTo(20*scaleX, i*scaleY); ctx.lineTo((LOGICAL_WIDTH-20)*scaleX, i*scaleY); ctx.stroke();
        }

        ctx.fillStyle = '#95a5a6';
        state.obstacles.forEach(obs => {
            ctx.fillRect(obs.x * scaleX, obs.y * scaleY, obs.w * scaleX, obs.h * scaleY);
            ctx.strokeRect(obs.x * scaleX, obs.y * scaleY, obs.w * scaleX, obs.h * scaleY);
        });

        const rx = state.robot.x * scaleX;
        const ry = state.robot.y * scaleY;
        const rSize = 20 * Math.min(scaleX, scaleY) * 1.5;
        ctx.font = `${rSize}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🤖', rx, ry);
    }
};

window.addEventListener('resize', () => MapEngine.draw());
setTimeout(() => { MapEngine.draw(); }, 100);
