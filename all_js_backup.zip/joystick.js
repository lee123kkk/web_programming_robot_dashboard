// joystick.js: Flask API로 제어 명령 전송

const joyBtns = {
    'joy-up': 'move_up',
    'joy-down': 'move_down',
    'joy-left': 'move_left',
    'joy-right': 'move_right',
    'joy-stop': 'stop'
};

Object.keys(joyBtns).forEach(id => {
    const btn = document.getElementById(id);
    if (btn) {
        btn.addEventListener('click', async () => {
            const action = joyBtns[id];
            
            // 맵 엔진에도 즉시 반영 (반응성을 위해)
            if (window.MapEngine && action !== 'stop') {
                const step = 20;
                if(id === 'joy-up') MapEngine.moveRobot(0, -step);
                if(id === 'joy-down') MapEngine.moveRobot(0, step);
                if(id === 'joy-left') MapEngine.moveRobot(-step, 0);
                if(id === 'joy-right') MapEngine.moveRobot(step, 0);
            }

            // Flask 서버로 명령 전송
            await fetch('/api/v1/robot/control', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: action })
            });
        });
    }
});
