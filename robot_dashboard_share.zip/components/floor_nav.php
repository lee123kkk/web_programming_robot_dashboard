<div class="box floor-nav">
    <ul>
        <li>10F</li><li>9F</li><li>8F</li><li>7F</li><li>6F</li><li>5F</li>
        <li>4F</li><li>3F</li><li>2F</li><li class="active">1F</li>
        <li>B1F</li><li>B2F</li><li>B3F</li>
    </ul>
</div>

