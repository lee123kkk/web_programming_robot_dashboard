<header class="box header">
    <div class="search-box"><span>🔍</span><input type="text" placeholder="검색"></div>
    <div class="header-right">
        <span class="user-role">최고 관리자</span><span class="user-name">hyundai.kim</span>
        <span class="noti-icon">🔔<span class="badge">14</span></span>
        <span class="lang">KR ⌄</span><span class="time">59:48 연장</span>
        <button class="logout-btn">로그아웃</button>
    </div>
</header>
