<nav class="box sidebar">
    <div class="logo"><span class="logo-icon">〰️</span> NARCHON</div>
    <ul class="nav-menu">
        <li>⭐ 즐겨찾기</li>
        <li>📊 대시보드</li>
        <li class="active">🖥️ 모니터링</li>
        <li>🤖 로봇 운영</li>
        <li>📋 시나리오</li>
        <li>🛠️ 로봇 서비스</li>
        <li>📝 로그</li>
        <li>⚙️ 설정</li>
    </ul>
</nav>
